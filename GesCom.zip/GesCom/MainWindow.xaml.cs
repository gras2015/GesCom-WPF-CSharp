﻿using GesCom.DataSet;
using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GesCom
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : System.Windows.Window
    {
       private List<Client> ListClient = new List<Client>();

        private Microsoft.Office.Interop.Excel.Application excel;
        private Workbook classeur;
        private Worksheet feuille;

        public MainWindow()

        {
            InitializeComponent();
            excel = new Microsoft.Office.Interop.Excel.Application();
            classeur = excel.Workbooks.Open(@"C:\Users\admin\Documents\Microsoft_interop\Gescom1.xlsx");
            feuille = classeur.Worksheets["Client"];

            //Créer la liste des clients
           

            int i = 2;
           
            // ligne avec clients
            //Boucle while jusqu'a la ligne vide
            while (feuille.Cells[i, 1].Text != string.Empty)
            {
                Client courant = new Client()
                {
                Id = int.Parse(feuille.Cells[i, 1].Text),
                Prenom = feuille.Cells[i, 2].Text,
                Nom = feuille.Cells[i, 3].Text,
                Mail = feuille.Cells[i, 4].Text,
                Tel = feuille.Cells[i, 5].Text,
                Societe = feuille.Cells[i, 6].Text
                };
              
                //Ajouter à la liste Client
                ListClient.Add(courant);
                i++;
               
            }
            classeur.Close();
            excel.Quit();
            DataClient.ItemsSource = ListClient;


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AjoutClient window = new AjoutClient();
            window.Id = DataClient.Items.Count; //+1  pour rajouter et passer le suivant
            window.ShowDialog();
            // Client courantClient = window.Client;
            //ListClient.Add(courantClient);

            ListClient.Add(window.Client);

            DataClient.ItemsSource = null;
            DataClient.ItemsSource = ListClient;

            //On ouvre le classeur
            excel = new Microsoft.Office.Interop.Excel.Application();
            classeur = excel.Workbooks.Open(@"C:\Users\admin\Documents\Microsoft_interop\Gescom1.xlsx");
            feuille = classeur.Worksheets["Client"];

           
            int i = 2;
                        
            while (feuille.Cells[i, 1].Text != string.Empty)
            {
                
                i++;

            }

            feuille.Cells[i, 1] = window.Client.Id;
            feuille.Cells[i, 2] = window.Client.Prenom;
            feuille.Cells[i, 3] = window.Client.Nom;
            feuille.Cells[i, 4] = window.Client.Mail;
            feuille.Cells[i, 5] = window.Client.Tel;
            feuille.Cells[i, 6] = window.Client.Societe;
        }
    }
}
