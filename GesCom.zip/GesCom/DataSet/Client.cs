﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GesCom.DataSet
{
     public class Client
    {
        public int Id { get; set; }
        public string Prenom { get; set; }
        public string Nom { get; set; }
        public string Mail { get; set; }
         public string Tel { get; set; }
        public string Societe { get; set; }
        //Constructeur de la classe Client
        public Client(int i, string p, string n, string m, string t, string s)
            : base()//constructeur de la base de la classe Client
        {
            Id = i;
            Prenom = p;
            Nom = n;
            Mail = m;
            Tel = t;
            Societe = s;
        }
        //Constructeur par recopie
        public Client(Client clientRecopie)
           : base()
        {
            Id = clientRecopie.Id;
            Prenom = clientRecopie.Prenom;
            Nom = clientRecopie.Nom;
            Mail = clientRecopie.Mail;
            Tel = clientRecopie.Tel;
            Societe = clientRecopie.Societe;

        }

        public Client()
        {
        }

        public override string ToString()
        {
            return Prenom + " " + Nom + " - " + Societe;
        }
    }
}
