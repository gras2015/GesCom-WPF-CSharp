﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GesCom.DataSet
{
      public class Article
    {
        public string Reference { get; set; }
        public string Designation { get; set; }
        public decimal MontantHT { get; set; }
        public  int ArticleID { get; set; }

        public Article(string r, string d, decimal m, int a)
            : base()//constructeur de la base de la classe Client
        {
            Reference = r;
            Designation = d;
            MontantHT = m;
            ArticleID = a;
            
        }

        public Article(Article articleRecopie)
           : base()
        {
            Reference = articleRecopie.Reference;
            Designation = articleRecopie.Designation;
            MontantHT = articleRecopie.MontantHT;
            ArticleID = articleRecopie.ArticleID;

        }

        public override string ToString()
        {
            return Reference + " " + ArticleID + " - " + MontantHT;
        }
    }
}
