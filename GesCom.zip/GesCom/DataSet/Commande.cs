﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GesCom.DataSet
{
    public class Commande
    {
        public int CommandeId { get; set; }
        public int ClientId { get; set; }
        public DateTime Date { get; set; }
        public int QuantiteTotal { get; set; }
        public decimal MontantTotal { get; set; }




        public Commande(int com, int cl, DateTime d, int q, decimal mon)
               : base()//constructeur de la base de la classe Client
        {
            CommandeId = com;
            ClientId = cl;
            Date = d;
            QuantiteTotal = q;
            MontantTotal = mon;

        }
        public Commande(Commande commandeRecopie)
           : base()
        {
            CommandeId = commandeRecopie.CommandeId;
            ClientId = commandeRecopie.ClientId;
            Date = commandeRecopie.Date;
            QuantiteTotal = commandeRecopie.QuantiteTotal;
            MontantTotal = commandeRecopie.MontantTotal;

        }

        public override string ToString()
        {
            return CommandeId + " " + ClientId + " - " + Date;
        }

    }
}
    