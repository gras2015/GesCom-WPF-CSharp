﻿using GesCom.DataSet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Office.Interop.Excel;
using Microsoft.Win32;

namespace GesCom
{
    /// <summary>
    /// Logique d'interaction pour AjoutClient.xaml
    /// </summary>
    public partial class AjoutClient : System.Windows.Window
    {
        public Client Client { get; set; }
        private List<string> ListSociete;
        private Microsoft.Office.Interop.Excel.Application excel;
        private Workbook classeur;
        private Worksheet feuille;
        public int Id { get; set; }
        public AjoutClient()
        {
            InitializeComponent();
            excel = new Microsoft.Office.Interop.Excel.Application();
            classeur = excel.Workbooks.Open(@"C:\Users\admin\Documents\Microsoft_interop\Gescom1.xlsx");
            feuille = classeur.Worksheets["Société"];

            //Créer la liste de société
            ListSociete = new List<string>();
            int i = 1;

            string temp = feuille.Cells[i, 1].Text; // ligne avec la Societe

            //Boucle while jusqu'a la ligne vide
                while (temp != string.Empty)
                {
                                                 
                             
                   //Ajouter à la liste Societe
                    ListSociete.Add(temp);
                i++;
                temp = feuille.Cells[i, 1].Text;

                }
                ComboSociete.ItemsSource = ListSociete;


        }

            private void Button_Click(object sender, RoutedEventArgs e)
            {
                Close();


            }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (Client == null)
            {
                Client = new Client(
               Id,
               TextPrenom.Text,
               TextNom.Text,
               TextMail.Text,
               TextTel.Text,
               ComboSociete.Text
               );
            }

            else
            {
                Client.Prenom = TextPrenom.Text;
                Client.Nom = TextNom.Text;
                Client.Mail = TextMail.Text;
                Client.Tel = TextTel.Text;
                Client.Societe = ComboSociete.Text;
            }

            Close();
        }
    }

    }

